var express = require('express');

var app = express();

//Importing data.json
var allSpeakers = require('./data/data.json');

app.get('/', (req, res) => {
    res.end('<h1>Welcome to Express JS</h1>');
});

app.get('/list', function (req, res) {
    res.write('<h1>This is the list page</h1>');
    res.end();
});

app.get('/test', function (req, res) {
    res.write('<h1>Checking Nodemon</h1>');
    res.end();
});

app.get('/speakers', (req, res) => {
    var speakers = '';
    allSpeakers.speakers.forEach(speaker => {
        speakers += `<li style="list-style-type:none">
                        <h2>Name: ${speaker.name}</h2>
                        <h3>Ttile: ${speaker.title}</h3>
                        <p>${speaker.summary}</p>
                     </li>`;
    });
    res.write('<h1>Information about speakers</h1>');
    res.write(speakers);
    res.end();
});

var server = app.listen(3000, () => {
    console.log('Server listening on port 3000!');
});